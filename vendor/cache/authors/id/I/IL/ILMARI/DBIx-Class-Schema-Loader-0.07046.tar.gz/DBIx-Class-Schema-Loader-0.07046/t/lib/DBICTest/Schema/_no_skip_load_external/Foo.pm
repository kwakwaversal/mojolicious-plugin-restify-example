package DBICTest::Schema::_no_skip_load_external::Foo;
use strict;
use warnings;

our $skip_me = "bad mojo";
1;
