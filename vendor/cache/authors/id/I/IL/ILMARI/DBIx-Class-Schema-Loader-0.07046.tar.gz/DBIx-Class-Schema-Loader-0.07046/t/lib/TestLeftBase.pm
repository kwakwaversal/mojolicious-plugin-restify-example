package TestLeftBase;
use strict;
use warnings;

sub test_additional_base_override { return "test_left_base_override"; }

1;
