package # Hide from PAUSE
  DBIx::Class::SQLAHacks::Oracle;

use warnings;
use strict;

use base qw( DBIx::Class::SQLMaker::Oracle );

1;
